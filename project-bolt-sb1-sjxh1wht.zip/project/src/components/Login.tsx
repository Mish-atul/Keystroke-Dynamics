import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { KeystrokeInput } from './KeystrokeInput';
import { useAuthStore } from '../store/authStore';
import { calculateKeystrokeMetrics, comparePatterns } from '../utils/keystrokeAnalysis';
import { KeystrokeData } from '../types/auth';
import { LogIn } from 'lucide-react';

export function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showOTP, setShowOTP] = useState(false);
  const [otp, setOTP] = useState('');
  const { getUser, setCurrentUser } = useAuthStore();

  const handleKeystrokeComplete = (keystrokes: KeystrokeData[]) => {
    const user = getUser(username);
    
    if (!user || user.password !== password) {
      alert('Invalid credentials');
      return;
    }

    const currentPattern = calculateKeystrokeMetrics(keystrokes);
    const isAuthentic = comparePatterns(user.keystrokePatterns, currentPattern);

    if (isAuthentic) {
      setCurrentUser(username);
      navigate('/dashboard');
    } else {
      setShowOTP(true);
    }
  };

  const handleOTPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, verify OTP here
    if (otp === '123456') { // Demo OTP
      setCurrentUser(username);
      navigate('/dashboard');
    } else {
      alert('Invalid OTP');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <div className="flex items-center justify-center mb-6">
          <LogIn className="w-12 h-12 text-blue-500" />
        </div>
        <h2 className="text-2xl font-bold text-center mb-6">Login</h2>

        {!showOTP ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <KeystrokeInput
                value={username}
                onChange={setUsername}
                onComplete={() => {}}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <KeystrokeInput
                type="password"
                value={password}
                onChange={setPassword}
                onComplete={handleKeystrokeComplete}
              />
            </div>

            <p className="text-sm text-gray-600">
              Press Enter after typing your password
            </p>
          </div>
        ) : (
          <form onSubmit={handleOTPSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Enter OTP
              </label>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOTP(e.target.value)}
                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter 6-digit OTP"
              />
            </div>
            
            <button
              type="submit"
              className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors"
            >
              Verify OTP
            </button>
          </form>
        )}
      </div>
    </div>
  );
}