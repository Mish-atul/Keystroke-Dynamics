import { create } from 'zustand';
import { UserData, KeystrokePattern } from '../types/auth';

interface AuthState {
  users: UserData[];
  currentUser: string | null;
  addUser: (userData: UserData) => void;
  addKeystrokePattern: (username: string, pattern: KeystrokePattern) => void;
  getUser: (username: string) => UserData | undefined;
  setCurrentUser: (username: string | null) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  users: [],
  currentUser: null,
  addUser: (userData) => {
    set((state) => ({
      users: [...state.users, userData],
    }));
  },
  addKeystrokePattern: (username, pattern) => {
    set((state) => ({
      users: state.users.map((user) =>
        user.username === username
          ? {
              ...user,
              keystrokePatterns: [...user.keystrokePatterns, pattern],
            }
          : user
      ),
    }));
  },
  getUser: (username) => {
    return get().users.find((user) => user.username === username);
  },
  setCurrentUser: (username) => {
    set({ currentUser: username });
  },
}));